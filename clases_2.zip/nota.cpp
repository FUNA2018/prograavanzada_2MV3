//** nota.cpp - Implementa la clase NOTA

#include <iostream>
using namespace std;

#include "nota.h"

//Inicializaci�n en alcance de archivo
int NOTA::count = 0;

/** Contructor por defecto para llevar la cuenta de cuantos objetos se han instanciado.
    Tambi�n se muestra el uso de inicializadores.
*/
NOTA::NOTA():intFecha(19840101),stringFecha(""),
stringDestinatario(""),stringRemitente(""),stringContenidoDeNota(""){
             NOTA::count++;
             }
// Destructor
NOTA::~NOTA(){
              NOTA::count--;
              }             
             
// M�tiodos de la clase
void NOTA::mostrar(){ //Ejemplo de un m�todo
           cout<<"Fecha: ";
           cout<<stringFecha<<endl;
           cout<<"Para:"<<stringDestinatario<<endl;
           cout<<"De:"<<stringRemitente<<endl;
           cout<<stringContenidoDeNota<<endl;
           }

int NOTA::get_count(){
    return count;
    }
