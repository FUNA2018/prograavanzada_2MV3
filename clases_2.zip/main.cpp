#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

#include "nota.h"

#define ABC
// Ejemplo de una macro
#define max(a,b) (a>b)?a:b;

#ifdef __unix__
// Se ejecuta si la aplicaci�n esta en Linux
#endif
/*
#ifndef _win32
#error Estamos en Windows
#endif
*/

int main(int argc, char *argv[]){
    NOTA Nota;
    cout<<"Count = "<<NOTA::count<<endl;
    Nota.intFecha = 20180810;
    char str[20];
    sprintf(str,"%d",Nota.intFecha);
    Nota.stringFecha = string(str);
    Nota.stringRemitente = "Quien recibe";
    Nota.stringDestinatario = "Quien manda";
    Nota.stringContenidoDeNota = "Mensaje generico";
    int A = 10,B = 20, C;
    C = max(A,B); // El pre-procesador reemplaza con C = A>B?A:B;
    printf("C = %d \n",C);
#ifdef ABC
    Nota.mostrar();
#endif
    cout<<"Nota.count "<<Nota.count<<endl;
    printf("\n*************************************************************\n");
    NOTA Nota1;
    cout<<"Count = "<<NOTA::count<<endl;
    Nota1.mostrar();
    printf("\n*************************************************************\n");
    cout<<"Nota.intFecha "<<Nota.intFecha<<endl;
    cout<<"Nota1.intFecha "<<Nota1.intFecha<<endl;
    cout<<endl;
    cout<<"Nota.count "<<Nota.count<<endl;
    cout<<"Nota1.count "<<Nota1.count<<endl;
    cout<<endl;
    void funcion();
    funcion();
    cout<<"Nota.count "<<Nota.count<<endl;
    cout<<"Nota.get_count()="<<Nota.get_count()<<endl;
    

    system("PAUSE");
    return EXIT_SUCCESS;
} // END

void funcion(){
     NOTA Nota2;
     Nota2.intFecha = 20100101;
    cout<<"Nota.count "<<Nota2.count<<endl;
    

     }
