/**
*Clase para representar Notas de recordatorio
* o posiblemente notas de pie de p�gina.
*Una nota que podr�amos anotar por ejemplo en un post it.
*Esta clase tambi�n muestra como podemos declarar
*clases sin secciones privados
*/
struct NOTA{
      int intFecha;    // Ejemplo de variable de objeto
      string stringFecha;       
      string stringContenidoDeNota;
      string stringRemitente;
      string stringDestinatario;
      
      static int count;  //Ejemplo de variable de clase
      
      //Constructor por defecto
      NOTA();
      //Destructor de objeto
      ~NOTA();
      // M�todos
      void mostrar();
      int get_count();
       }; //end struct NOTA
