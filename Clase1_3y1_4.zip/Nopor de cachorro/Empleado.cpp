//*** Empleado.cpp - Resuelve los m�todos de la clase empleado

#include <iostream>
using namespace std;
/*using std::cout;
using std::cin;
using std::endl;
*/

#include <cstring>
using std::strlen;
using std::strcpy;

#include "Empleado.h"

Empleado::Empleado(const char* const nombre,const char* const apellido){
    PrimerNombre = new char[strlen(nombre)+1];
    strcpy(PrimerNombre,nombre);
    
    ApellidoPaterno = new char[strlen(nombre)+1];
    strcpy(ApellidoPaterno,apellido);
    
    cuenta++;
    
    cout<<"Se llamo al constructor de empleado para "<<PrimerNombre<<" "
    <<ApellidoPaterno<<"."<<endl;
    }
// El destructor desasigna la memoria asignada de forma din�mica
Empleado::~Empleado(){
    cout<<"Se llamo a ~Empleado para "<<PrimerNombre<<" "
    <<ApellidoPaterno<<"."<<endl;
    delete [] PrimerNombre;
    delete [] ApellidoPaterno;
    cuenta--;
                          }
                          
const char* Empleado::getPrimerNombre() const{
    return PrimerNombre;
    }
                          
const char* Empleado::getApellidoPaterno() const{
    return ApellidoPaterno;
    }                              

int Empleado::getCuenta(){
    return cuenta;
    }
