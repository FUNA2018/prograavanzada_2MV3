#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    cout<<"Hola Mundo"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
