//** TestEmpleado.cpp - Usa la clase Empleado
#include <cstdlib>
#include <iostream>
using namespace std;

#include "Empleado.h"

int main(int argc, char *argv[])
{
    
    cout<<"El n�mero de empleados antes de instanciar cualquier objeto es "
    <<Empleado::getCuenta()<<endl;
    
    Empleado *e1Ptr = new Empleado("Susan","Baker");
    Empleado *e2Ptr = new Empleado("Robert","Jones");

    cout<<"El n�mero de empleados despu�s de instanciar cualquier objeto es "
    <<Empleado::getCuenta()<<endl;
    


    system("PAUSE");  
    //return EXIT_SUCCESS;
    return 0;
}
