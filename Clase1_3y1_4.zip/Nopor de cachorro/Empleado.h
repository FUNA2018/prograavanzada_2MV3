//** Empleado.h - Declara la clase empleado 
#ifndef EMPLEADO_H
#define EMPLEADO_H
class Empleado{
// ** M�todos de la clase
      public:
             Empleado(const char* const, const char* const); // Constructor
             ~Empleado(); // Destructor
             const char* getPrimerNombre() const; // Devuelve el primer nombre
             const char* getApellidoPaterno() const; // Devuelve el apellido paterno
             
      static int getCuenta(); // Devuelve el n�mero de objetos instanciados

// ** Atributos de la clase
      private:
              char* PrimerNombre;
              char* ApellidoPaterno;

      static int cuenta;
             
      }; // Fin de clase Empleado
      
#endif // EMPLEADO_H
