#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

/**
*Clase para representar Notas de recordatorio
* o posiblemente notas de pie de p�gina.
*Una nota que podr�amos anotar por ejemplo en un post it.
*Esta clase tambi�n muestra como podemos declarar
*clases sin secciones privados
*/
struct NOTA{
      int intFecha;
      string stringFecha;       
      string stringContenidoDeNota;
      string stringRemitente;
      string stringDestinatario;
      void mostrar(){ //Ejemplo de un m�todo
           cout<<"Fecha: ";
           cout<<stringFecha<<endl;
           cout<<"Para:"<<stringDestinatario<<endl;
           cout<<"De:"<<stringRemitente<<endl;
           cout<<stringContenidoDeNota<<endl;
           }
       }; //end struct
       

int main(int argc, char *argv[]){
    NOTA Nota;
    Nota.intFecha = 20180810;
    char str[20];
    sprintf(str,"%d",Nota.intFecha);
    Nota.stringFecha = string(str);
    Nota.stringRemitente = "Su cola";
    Nota.stringDestinatario = "Mariachanga";
    Nota.stringContenidoDeNota = "holi, boli, crayoli, pozoli, pistoli, coriolli, bernoulli, zenoni, rabioli, ivoni dame la formuoli";
    Nota.mostrar();

    cout<<"IZI BICI"<<endl;
    cout<<"Tu GFA en bici :v"<<endl;
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
