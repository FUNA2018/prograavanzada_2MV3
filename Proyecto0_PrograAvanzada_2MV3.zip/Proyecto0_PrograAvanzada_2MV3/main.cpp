#include <cstdlib>
#include <iostream>

using namespace std; /*cin, cout, endl*/
#define ARCHIVO_TXT c:/Users/Sala5/archivo.txt //resspaldo de datos

int main(int argc, char *argv[])
{
    cout<<"Hola Mundo C++ Curso Programaci\'on Avanzada"<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
